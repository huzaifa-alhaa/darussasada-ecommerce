import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";
import heroImage from "@/assets/hero-perfumes.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center bg-gradient-elegant pt-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Content */}
          <div className="space-y-8 text-center lg:text-left">
            <div className="space-y-4">
              <div className="inline-flex items-center px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium">
                <Sparkles className="h-4 w-4 mr-2" />
                Premium Collection
              </div>
              
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-playfair font-bold text-foreground leading-tight">
                Luxury
                <span className="block bg-gradient-primary bg-clip-text text-transparent">
                  Perfumes
                </span>
                & Cosmetics
              </h1>
              
              <p className="text-base md:text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto lg:mx-0">
                Discover the finest collection of authentic Arabic perfumes and premium cosmetics. 
                Experience elegance and sophistication with every fragrance.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button size="lg" className="bg-gradient-primary hover:shadow-glow transition-all duration-300 group">
                Shop Collection
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button variant="outline" size="lg" className="border-primary/20 hover:bg-primary/5">
                Explore Fragrances
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 sm:gap-8 pt-6 lg:pt-8 border-t border-border/50">
              <div className="text-center lg:text-left">
                <div className="text-xl sm:text-2xl font-playfair font-bold text-primary">500+</div>
                <div className="text-xs sm:text-sm text-muted-foreground">Premium Products</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-xl sm:text-2xl font-playfair font-bold text-primary">10K+</div>
                <div className="text-xs sm:text-sm text-muted-foreground">Happy Customers</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-xl sm:text-2xl font-playfair font-bold text-primary">5★</div>
                <div className="text-xs sm:text-sm text-muted-foreground">Customer Rating</div>
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="relative order-first lg:order-last">
            <div className="relative z-10">
              <img 
                src={heroImage} 
                alt="Luxury perfumes and cosmetics collection"
                className="w-full h-[400px] sm:h-[500px] lg:h-[600px] object-cover rounded-2xl shadow-luxury"
              />
              
              {/* Floating elements */}
              <div className="absolute top-4 right-4 sm:top-8 sm:right-8 bg-background/90 backdrop-blur-sm rounded-lg p-3 sm:p-4 shadow-lg">
                <div className="text-xs sm:text-sm text-muted-foreground">Starting from</div>
                <div className="text-lg sm:text-xl font-playfair font-bold text-primary">₦15,000</div>
              </div>
              
              <div className="absolute bottom-4 left-4 sm:bottom-8 sm:left-8 bg-background/90 backdrop-blur-sm rounded-lg p-3 sm:p-4 shadow-lg">
                <div className="text-xs sm:text-sm text-muted-foreground">Free Delivery</div>
                <div className="text-sm sm:text-lg font-medium text-foreground">Nationwide</div>
              </div>
            </div>
            
            {/* Background decoration */}
            <div className="absolute -top-2 -right-2 sm:-top-4 sm:-right-4 w-full h-full bg-gradient-secondary opacity-20 rounded-2xl -z-10"></div>
          </div>
        </div>
      </div>
      
      {/* Background pattern */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM5Nzc3YmIiIGZpbGwtb3BhY2l0eT0iMC4xIj48Y2lyY2xlIGN4PSIzMCIgY3k9IjMwIiByPSI0Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-30"></div>
    </section>
  );
};

export default Hero;