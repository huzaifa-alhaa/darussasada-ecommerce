import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShoppingCart, User, Menu, X, Search, LogOut, Heart, Shield } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from './ui/dropdown-menu';
import { useAuth } from '@/hooks/useAuth';
import { useAdminAuth } from '@/hooks/useAdminAuth';
import { toast } from 'sonner';
import { Link, useLocation } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import Cart from './Cart';

interface HeaderProps {
  cartItems: number;
  onCartClick: () => void;
}

const Header = ({ cartItems, onCartClick }: HeaderProps) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { user, loading, signOut } = useAuth();
  const { isAdmin } = useAdminAuth();
  const navigate = useNavigate();

  const navigation = [
    { name: "Home", href: "/" },
    { name: "Products", href: "/products" },
    { name: "About", href: "#about" },
    { name: "Contact", href: "#contact" }
  ];

  const isActiveRoute = (href: string) => {
    if (href === "/" && location.pathname === "/") return true;
    if (href !== "/" && location.pathname.startsWith(href)) return true;
    return false;
  };

  const handleSignOut = async () => {
    const { error } = await signOut();
    if (error) {
      toast.error('Error signing out');
    } else {
      toast.success('Signed out successfully');
      navigate('/');
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="text-xl sm:text-2xl font-playfair font-bold bg-gradient-primary bg-clip-text text-transparent hover:opacity-80 transition-opacity">
              DARUS-SA'ADA
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6 lg:space-x-8">
            {navigation.map((item) => (
              item.href.startsWith('#') ? (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-sm font-medium text-foreground hover:text-primary transition-colors"
                >
                  {item.name}
                </a>
              ) : (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`text-sm font-medium transition-colors ${
                    isActiveRoute(item.href) 
                      ? 'text-primary font-semibold' 
                      : 'text-foreground hover:text-primary'
                  }`}
                >
                  {item.name}
                </Link>
              )
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            <Button variant="ghost" size="sm" className="hidden sm:flex" aria-label="Search">
              <Search className="h-4 w-4" />
            </Button>
            
            {user && (
              <Link to="/account">
                <Button variant="ghost" size="sm" className="hidden sm:flex" aria-label="Wishlist">
                  <Heart className="h-4 w-4" />
                </Button>
              </Link>
            )}
            
            {!loading && (
              <>
                {user ? (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="hidden sm:flex" aria-label="My Account">
                        <User className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem asChild>
                        <Link to="/account">My Account</Link>
                      </DropdownMenuItem>
                      {isAdmin && (
                        <>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem asChild>
                            <Link to="/admin">
                              <Shield className="mr-2 h-4 w-4" />
                              Admin Dashboard
                            </Link>
                          </DropdownMenuItem>
                        </>
                      )}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleSignOut}>
                        <LogOut className="mr-2 h-4 w-4" />
                        Sign Out
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <Link to="/auth">
                    <Button variant="ghost" size="sm" className="hidden sm:flex" aria-label="Sign In">
                      <User className="h-4 w-4" />
                    </Button>
                  </Link>
                )}
              </>
            )}

            <Button variant="ghost" size="sm" onClick={onCartClick} className="relative" aria-label={`Shopping cart with ${cartItems} items`}>
              <ShoppingCart className="h-4 w-4" />
              {cartItems > 0 && (
                <Badge className="absolute -top-1 -right-1 h-4 w-4 min-w-4 rounded-full p-0 text-xs bg-primary text-primary-foreground flex items-center justify-center">
                  {cartItems > 99 ? '99+' : cartItems}
                </Badge>
              )}
            </Button>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden ml-2"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label={isMobileMenuOpen ? 'Close menu' : 'Open menu'}
            >
              {isMobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-background/95 backdrop-blur">
            <div className="px-2 pt-2 pb-3 space-y-1 border-t border-border">
              {navigation.map((item) => (
                item.href.startsWith('#') ? (
                  <a
                    key={item.name}
                    href={item.href}
                    className="block px-3 py-2 text-sm font-medium text-foreground hover:text-primary hover:bg-muted rounded-md transition-colors"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.name}
                  </a>
                ) : (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={`block px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      isActiveRoute(item.href) 
                        ? 'text-primary bg-muted font-semibold' 
                        : 'text-foreground hover:text-primary hover:bg-muted'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.name}
                  </Link>
                )
              ))}
              
              {/* Mobile-only actions */}
              <div className="flex flex-col space-y-2 px-3 py-2 border-t border-border mt-2">
                <Button variant="ghost" size="sm" aria-label="Search" className="justify-start">
                  <Search className="h-4 w-4" />
                  <span className="ml-2 text-sm">Search</span>
                </Button>
                
                {user ? (
                  <>
                    <Link to="/account" className="w-full">
                      <Button variant="ghost" size="sm" aria-label="Wishlist" className="w-full justify-start">
                        <Heart className="h-4 w-4" />
                        <span className="ml-2 text-sm">Wishlist</span>
                      </Button>
                    </Link>
                     <Link to="/account" className="w-full">
                       <Button variant="ghost" size="sm" aria-label="My Account" className="w-full justify-start">
                         <User className="h-4 w-4" />
                         <span className="ml-2 text-sm">My Account</span>
                       </Button>
                     </Link>
                     {isAdmin && (
                       <Link to="/admin" className="w-full">
                         <Button variant="ghost" size="sm" className="w-full justify-start">
                           <Shield className="h-4 w-4" />
                           <span className="ml-2 text-sm">Admin Dashboard</span>
                         </Button>
                       </Link>
                     )}
                     <Button variant="ghost" size="sm" onClick={handleSignOut} className="justify-start">
                       <LogOut className="h-4 w-4" />
                       <span className="ml-2 text-sm">Sign Out</span>
                     </Button>
                  </>
                ) : (
                  <Link to="/auth" className="w-full">
                    <Button variant="ghost" size="sm" aria-label="Sign In" className="w-full justify-start">
                      <User className="h-4 w-4" />
                      <span className="ml-2 text-sm">Sign In</span>
                    </Button>
                  </Link>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;