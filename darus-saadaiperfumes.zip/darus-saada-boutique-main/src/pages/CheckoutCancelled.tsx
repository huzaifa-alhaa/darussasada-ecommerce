import { Link } from "react-router-dom";
import { XCircle, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const CheckoutCancelled = () => {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md text-center">
        <CardHeader className="pb-4">
          <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <XCircle className="w-8 h-8 text-red-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-foreground">
            Payment Cancelled
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            Your payment was cancelled. No charges were made to your account.
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="text-sm text-muted-foreground space-y-2">
            <p>Don't worry - your cart items are still saved.</p>
            <p>You can continue shopping or try checkout again when you're ready.</p>
          </div>
          
          <div className="flex flex-col space-y-3">
            <Button asChild className="w-full">
              <Link to="/">
                <ArrowLeft className="mr-2 w-4 h-4" />
                Return to Shop
              </Link>
            </Button>
            
            <Button variant="outline" asChild className="w-full">
              <Link to="/products">
                Continue Shopping
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CheckoutCancelled;