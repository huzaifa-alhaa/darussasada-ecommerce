import { useEffect, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { CheckCircle, Package, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const CheckoutSuccess = () => {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('session_id');
  const [orderNumber] = useState(() => `ORD-${Date.now()}`);

  useEffect(() => {
    // Clear cart from localStorage since checkout was successful
    localStorage.removeItem('cart-items');
  }, []);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md text-center">
        <CardHeader className="pb-4">
          <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-foreground">
            Payment Successful!
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            Thank you for your purchase. Your order has been confirmed.
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="bg-muted p-4 rounded-lg">
            <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground mb-2">
              <Package className="w-4 h-4" />
              <span>Order Number</span>
            </div>
            <p className="font-mono text-lg font-semibold text-foreground">{orderNumber}</p>
          </div>

          <div className="text-sm text-muted-foreground space-y-2">
            <p>A confirmation email has been sent to your email address.</p>
            <p>You will receive tracking information once your order ships.</p>
          </div>
          
          <div className="flex flex-col space-y-3">
            <Button asChild className="w-full">
              <Link to="/products">
                Continue Shopping
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
            
            <Button variant="outline" asChild className="w-full">
              <Link to="/account">
                View Order History
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CheckoutSuccess;