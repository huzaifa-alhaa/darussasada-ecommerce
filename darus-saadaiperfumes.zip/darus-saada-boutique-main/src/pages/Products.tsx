import { useState } from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import ProductCard, { Product } from "@/components/ProductCard";
import Cart from "@/components/Cart";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Search, Filter, Grid, List } from "lucide-react";

// Import product images
import perfume1 from "@/assets/perfume-1.jpg";
import perfume2 from "@/assets/perfume-2.jpg";
import perfume3 from "@/assets/perfume-3.jpg";
import perfume4 from "@/assets/perfume-4.jpg";
import perfume5 from "@/assets/perfume-5.jpg";
import perfume6 from "@/assets/perfume-6.jpg";
import perfume7 from "@/assets/perfume-7.jpg";
import perfume8 from "@/assets/perfume-8.jpg";
import perfume9 from "@/assets/perfume-9.jpg";
import perfume10 from "@/assets/perfume-10.jpg";
import perfume11 from "@/assets/perfume-11.jpg";
import perfume12 from "@/assets/perfume-12.jpg";
import perfume13 from "@/assets/perfume-13.jpg";
import perfume14 from "@/assets/perfume-14.jpg";
import perfume15 from "@/assets/perfume-15.jpg";
import perfume16 from "@/assets/perfume-16.jpg";
import perfume17 from "@/assets/perfume-17.jpg";
import perfume18 from "@/assets/perfume-18.jpg";
import perfume19 from "@/assets/perfume-19.jpg";
import perfume20 from "@/assets/perfume-20.jpg";
import perfume21 from "@/assets/perfume-21.jpg";
import perfume22 from "@/assets/perfume-22.jpg";
import perfume23 from "@/assets/perfume-23.jpg";
import perfume24 from "@/assets/perfume-24.jpg";
import perfume25 from "@/assets/perfume-25.jpg";
import perfume26 from "@/assets/perfume-26.jpg";
import perfume27 from "@/assets/perfume-27.jpg";
import perfume28 from "@/assets/perfume-28.jpg";
import perfume29 from "@/assets/perfume-29.jpg";
import perfume30 from "@/assets/perfume-30.jpg";
import perfume31 from "@/assets/perfume-31.jpg";
import perfume32 from "@/assets/perfume-32.jpg";
import perfume33 from "@/assets/perfume-33.jpg";
import perfume34 from "@/assets/perfume-34.jpg";
import perfume35 from "@/assets/perfume-35.jpg";

interface CartItem extends Product {
  quantity: number;
}

const Products = () => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortBy, setSortBy] = useState("featured");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  // Extended product catalog
  const allProducts: Product[] = [
    {
      id: "1",
      name: "Oud Al Malaki Royal",
      price: 25000,
      originalPrice: 30000,
      image: perfume1,
      category: "Premium Oud",
      rating: 4.8,
      reviews: 127,
      isNew: true,
      isBestseller: true,
    },
    {
      id: "2",
      name: "Ameer Al Oud Original",
      price: 28000,
      originalPrice: 35000,
      image: perfume2,
      category: "Premium Oud",
      rating: 4.9,
      reviews: 156,
      isBestseller: true,
    },
    {
      id: "3",
      name: "Ramz Lattafa Black",
      price: 18000,
      image: perfume3,
      category: "Modern Fragrances",
      rating: 4.6,
      reviews: 89,
      isNew: true,
    },
    {
      id: "4",
      name: "Ramz Lattafa Red",
      price: 18000,
      image: perfume4,
      category: "Modern Fragrances",
      rating: 4.7,
      reviews: 92,
    },
    {
      id: "5",
      name: "Majestic Oud 24 Hours",
      price: 32000,
      originalPrice: 38000,
      image: perfume5,
      category: "Premium Oud",
      rating: 4.9,
      reviews: 203,
      isBestseller: true,
    },
    {
      id: "6",
      name: "Mousuf Azraq",
      price: 22000,
      image: perfume6,
      category: "Unisex Collection",
      rating: 4.5,
      reviews: 78,
      isNew: true,
    },
    {
      id: "7",
      name: "Desert Amber",
      price: 15000,
      image: perfume7,
      category: "Traditional Attar",
      rating: 4.4,
      reviews: 64,
    },
    {
      id: "8",
      name: "Rose Wardi",
      price: 20000,
      image: perfume8,
      category: "Women's Collection",
      rating: 4.7,
      reviews: 118,
      isBestseller: true,
    },
    {
      id: "9",
      name: "Yara Lattafa White",
      price: 16000,
      image: perfume9,
      category: "Women's Collection",
      rating: 4.6,
      reviews: 85,
    },
    {
      id: "10",
      name: "Asad Collection Set",
      price: 45000,
      originalPrice: 54000,
      image: perfume10,
      category: "Gift Sets",
      rating: 4.8,
      reviews: 97,
      isNew: true,
    },
    {
      id: "11",
      name: "Asad Bourbon Lattafa",
      price: 29000,
      originalPrice: 35000,
      image: perfume11,
      category: "Premium Oud",
      rating: 4.7,
      reviews: 134,
      isBestseller: true,
    },
    {
      id: "12",
      name: "Ameer Al Oudh Intense",
      price: 31000,
      image: perfume12,
      category: "Premium Oud",
      rating: 4.9,
      reviews: 198,
      isBestseller: true,
    },
    {
      id: "13",
      name: "Ameer Al Oudh Classic",
      price: 24000,
      originalPrice: 28000,
      image: perfume13,
      category: "Premium Oud",
      rating: 4.6,
      reviews: 112,
      isNew: true,
    },
    {
      id: "14",
      name: "Rameesah Gold Attar",
      price: 19000,
      image: perfume14,
      category: "Traditional Attar",
      rating: 4.8,
      reviews: 87,
      isBestseller: true,
    },
    {
      id: "15",
      name: "Burhan Crystal",
      price: 16000,
      image: perfume15,
      category: "Traditional Attar",
      rating: 4.5,
      reviews: 76,
    },
    {
      id: "16",
      name: "Burhan Concentrated Oil",
      price: 14000,
      originalPrice: 17000,
      image: perfume16,
      category: "Traditional Attar",
      rating: 4.4,
      reviews: 62,
      isNew: true,
    },
    {
      id: "17",
      name: "Jameelah Royal",
      price: 21000,
      image: perfume17,
      category: "Unisex Collection",
      rating: 4.7,
      reviews: 143,
      isBestseller: true,
    },
    {
      id: "18",
      name: "Dani Roll-On Oil",
      price: 12000,
      image: perfume18,
      category: "Traditional Attar",
      rating: 4.3,
      reviews: 54,
    },
    {
      id: "19",
      name: "Azhar Concentrated Oil",
      price: 13000,
      originalPrice: 16000,
      image: perfume19,
      category: "Traditional Attar",
      rating: 4.5,
      reviews: 68,
      isNew: true,
    },
    {
      id: "20",
      name: "Bushra Pure Oil",
      price: 15000,
      image: perfume20,
      category: "Traditional Attar",
      rating: 4.6,
      reviews: 91,
      isBestseller: true,
    },
    {
      id: "21",
      name: "Oud Bushra Royal",
      price: 18000,
      originalPrice: 22000,
      image: perfume21,
      category: "Premium Oud",
      rating: 4.7,
      reviews: 105,
      isNew: true,
    },
    {
      id: "22",
      name: "Tayiba Attar",
      price: 14000,
      image: perfume22,
      category: "Traditional Attar",
      rating: 4.4,
      reviews: 73,
    },
    {
      id: "23",
      name: "Burhan Roll-On",
      price: 11000,
      image: perfume23,
      category: "Traditional Attar",
      rating: 4.3,
      reviews: 58,
    },
    {
      id: "24",
      name: "Khalifa Gold",
      price: 26000,
      originalPrice: 31000,
      image: perfume24,
      category: "Premium Oud",
      rating: 4.8,
      reviews: 129,
      isBestseller: true,
    },
    {
      id: "25",
      name: "Musk Safi Attar",
      price: 17000,
      image: perfume25,
      category: "Unisex Collection",
      rating: 4.5,
      reviews: 84,
    },
    {
      id: "26",
      name: "Ikhlas Concentrated Oil",
      price: 16000,
      originalPrice: 19000,
      image: perfume26,
      category: "Traditional Attar",
      rating: 4.6,
      reviews: 77,
      isNew: true,
    },
    {
      id: "27",
      name: "Laeqa Royal Oil",
      price: 22000,
      image: perfume27,
      category: "Premium Oud",
      rating: 4.7,
      reviews: 112,
      isBestseller: true,
    },
    {
      id: "28",
      name: "Surrati Fehranheit",
      price: 9000,
      image: perfume28,
      category: "Concentrated Oils",
      rating: 4.2,
      reviews: 46,
    },
    {
      id: "29",
      name: "Surrati Professional",
      price: 8500,
      image: perfume29,
      category: "Concentrated Oils",
      rating: 4.1,
      reviews: 39,
    },
    {
      id: "30",
      name: "Surrati 121 VIP",
      price: 9500,
      image: perfume30,
      category: "Concentrated Oils",
      rating: 4.3,
      reviews: 52,
      isNew: true,
    },
    {
      id: "31",
      name: "Surrati Tom Oud",
      price: 11000,
      image: perfume31,
      category: "Concentrated Oils",
      rating: 4.4,
      reviews: 67,
      isBestseller: true,
    },
    {
      id: "32",
      name: "Surrati Black Horse",
      price: 10000,
      originalPrice: 12000,
      image: perfume32,
      category: "Concentrated Oils",
      rating: 4.2,
      reviews: 43,
      isNew: true,
    },
    {
      id: "33",
      name: "Surrati Hojo",
      price: 9000,
      image: perfume33,
      category: "Concentrated Oils",
      rating: 4.1,
      reviews: 38,
    },
    {
      id: "34",
      name: "Black Oud Premium",
      price: 19000,
      originalPrice: 23000,
      image: perfume34,
      category: "Premium Oud",
      rating: 4.6,
      reviews: 98,
      isBestseller: true,
    },
    {
      id: "35",
      name: "Ikhlas Royal Gold",
      price: 28000,
      originalPrice: 34000,
      image: perfume35,
      category: "Premium Oud",
      rating: 4.8,
      reviews: 147,
      isBestseller: true,
    },
  ];

  const categories = [
    "all",
    "Premium Oud",
    "Modern Fragrances", 
    "Traditional Attar",
    "Women's Collection",
    "Unisex Collection",
    "Gift Sets",
    "Concentrated Oils"
  ];

  // Filter and sort products
  const filteredProducts = allProducts
    .filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           product.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === "all" || product.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.price - b.price;
        case "price-high":
          return b.price - a.price;
        case "rating":
          return b.rating - a.rating;
        case "newest":
          return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
        default:
          return (b.isBestseller ? 1 : 0) - (a.isBestseller ? 1 : 0);
      }
    });

  const addToCart = (product: Product) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id 
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity === 0) {
      removeItem(productId);
      return;
    }
    setCartItems(prev => 
      prev.map(item => 
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const removeItem = (productId: string) => {
    setCartItems(prev => prev.filter(item => item.id !== productId));
  };

  const toggleFavorite = (productId: string) => {
    setFavorites(prev => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(productId)) {
        newFavorites.delete(productId);
      } else {
        newFavorites.add(productId);
      }
      return newFavorites;
    });
  };

  const totalCartItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-gradient-elegant">
      <Header 
        cartItems={totalCartItems} 
        onCartClick={() => setIsCartOpen(true)} 
      />
      
      <main className="pt-24">
        {/* Header Section */}
        <section className="py-12 bg-background/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
              <Link to="/" className="hover:text-primary transition-colors">Home</Link>
              <span>/</span>
              <span className="text-foreground">Products</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-playfair font-bold text-foreground mb-4">
              Our <span className="text-primary">Collection</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Discover our complete range of authentic Arabic perfumes and luxury fragrances
            </p>
          </div>
        </section>

        {/* Filters and Search */}
        <section className="py-8 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row gap-6 items-start lg:items-center justify-between">
              {/* Search */}
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* Filters */}
              <div className="flex flex-wrap gap-4 items-center">
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>
                        {category === "all" ? "All Categories" : category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="featured">Featured</SelectItem>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                  </SelectContent>
                </Select>

                {/* View Mode Toggle */}
                <div className="flex border rounded-lg">
                  <Button
                    variant={viewMode === "grid" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                    className="rounded-r-none"
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                    className="rounded-l-none"
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Active Filters */}
            <div className="flex flex-wrap gap-2 mt-4">
              {selectedCategory !== "all" && (
                <Badge variant="secondary" className="gap-2">
                  {selectedCategory}
                  <button 
                    onClick={() => setSelectedCategory("all")}
                    className="hover:text-destructive"
                  >
                    ×
                  </button>
                </Badge>
              )}
              {searchQuery && (
                <Badge variant="secondary" className="gap-2">
                  Search: "{searchQuery}"
                  <button 
                    onClick={() => setSearchQuery("")}
                    className="hover:text-destructive"
                  >
                    ×
                  </button>
                </Badge>
              )}
            </div>

            {/* Results Count */}
            <p className="text-sm text-muted-foreground mt-4">
              Showing {filteredProducts.length} of {allProducts.length} products
            </p>
          </div>
        </section>

        {/* Products Grid */}
        <section className="py-12">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            {filteredProducts.length === 0 ? (
              <div className="text-center py-16">
                <h3 className="text-xl font-semibold text-foreground mb-2">No products found</h3>
                <p className="text-muted-foreground mb-6">Try adjusting your search or filter criteria</p>
                <Button onClick={() => {
                  setSearchQuery("");
                  setSelectedCategory("all");
                }}>
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className={`grid ${
                viewMode === "grid" 
                  ? "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" 
                  : "grid-cols-1 lg:grid-cols-2"
                } gap-4 sm:gap-6 lg:gap-8`}>
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onAddToCart={addToCart}
                    onToggleFavorite={toggleFavorite}
                    isFavorite={favorites.has(product.id)}
                  />
                ))}
              </div>
            )}
          </div>
        </section>
      </main>

      <Cart
        isOpen={isCartOpen}
        onOpenChange={setIsCartOpen}
        items={cartItems}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeItem}
      />
    </div>
  );
};

export default Products;