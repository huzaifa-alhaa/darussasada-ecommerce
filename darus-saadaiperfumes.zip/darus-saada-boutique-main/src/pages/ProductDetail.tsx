import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import Header from "@/components/Header";
import ProductCard, { Product } from "@/components/ProductCard";
import Cart from "@/components/Cart";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Star, 
  ShoppingCart, 
  Heart, 
  Share2, 
  ArrowLeft,
  Plus,
  Minus,
  Shield,
  Truck,
  RotateCcw
} from "lucide-react";

// Import product images
import perfume1 from "@/assets/perfume-1.jpg";
import perfume2 from "@/assets/perfume-2.jpg";
import perfume3 from "@/assets/perfume-3.jpg";
import perfume4 from "@/assets/perfume-4.jpg";
import perfume5 from "@/assets/perfume-5.jpg";
import perfume6 from "@/assets/perfume-6.jpg";
import perfume7 from "@/assets/perfume-7.jpg";
import perfume8 from "@/assets/perfume-8.jpg";
import perfume9 from "@/assets/perfume-9.jpg";
import perfume10 from "@/assets/perfume-10.jpg";
import perfume11 from "@/assets/perfume-11.jpg";
import perfume12 from "@/assets/perfume-12.jpg";
import perfume13 from "@/assets/perfume-13.jpg";
import perfume14 from "@/assets/perfume-14.jpg";
import perfume15 from "@/assets/perfume-15.jpg";
import perfume16 from "@/assets/perfume-16.jpg";
import perfume17 from "@/assets/perfume-17.jpg";
import perfume18 from "@/assets/perfume-18.jpg";
import perfume19 from "@/assets/perfume-19.jpg";
import perfume20 from "@/assets/perfume-20.jpg";
import perfume21 from "@/assets/perfume-21.jpg";
import perfume22 from "@/assets/perfume-22.jpg";
import perfume23 from "@/assets/perfume-23.jpg";
import perfume24 from "@/assets/perfume-24.jpg";
import perfume25 from "@/assets/perfume-25.jpg";
import perfume26 from "@/assets/perfume-26.jpg";
import perfume27 from "@/assets/perfume-27.jpg";
import perfume28 from "@/assets/perfume-28.jpg";
import perfume29 from "@/assets/perfume-29.jpg";
import perfume30 from "@/assets/perfume-30.jpg";
import perfume31 from "@/assets/perfume-31.jpg";
import perfume32 from "@/assets/perfume-32.jpg";
import perfume33 from "@/assets/perfume-33.jpg";
import perfume34 from "@/assets/perfume-34.jpg";
import perfume35 from "@/assets/perfume-35.jpg";

interface DetailedProduct extends Product {
  description: string;
  ingredients: string[];
  volume: string;
  brand: string;
  concentration: string;
  longevity: string;
  sillage: string;
  additionalImages?: string[];
}

interface CartItem extends Product {
  quantity: number;
}

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);

  // Extended product data with detailed information
  const detailedProducts: DetailedProduct[] = [
    {
      id: "1",
      name: "Oud Al Malaki Royal",
      price: 25000,
      originalPrice: 30000,
      image: perfume1,
      category: "Premium Oud",
      rating: 4.8,
      reviews: 127,
      isNew: true,
      isBestseller: true,
      description: "Experience the epitome of luxury with Oud Al Malaki Royal, a masterfully crafted fragrance that embodies the essence of royal elegance. This exquisite oud perfume opens with rich, smoky notes of premium agarwood, complemented by warm spices and precious amber. The heart reveals delicate rose and jasmine, while the base settles into a profound blend of sandalwood, musk, and vanilla.",
      ingredients: ["Agarwood (Oud)", "Rose", "Jasmine", "Amber", "Sandalwood", "Musk", "Vanilla", "Spices"],
      volume: "100ml",
      brand: "Al Malaki",
      concentration: "Parfum",
      longevity: "8-12 hours",
      sillage: "Heavy",
      additionalImages: [perfume1, perfume11, perfume24]
    },
    {
      id: "2",
      name: "Ameer Al Oud Original",
      price: 28000,
      originalPrice: 35000,
      image: perfume2,
      category: "Premium Oud",
      rating: 4.9,
      reviews: 156,
      isBestseller: true,
      description: "Ameer Al Oud Original is a distinguished fragrance that captures the authentic spirit of traditional Arabic perfumery. This sophisticated blend features the finest Cambodian oud as its centerpiece, enhanced by aromatic saffron and cardamom in the opening. The composition evolves into a heart of damascus rose and white flowers, concluding with a rich base of aged sandalwood and white musk.",
      ingredients: ["Cambodian Oud", "Saffron", "Cardamom", "Damascus Rose", "White Flowers", "Sandalwood", "White Musk"],
      volume: "100ml",
      brand: "Ameer Al Oud",
      concentration: "Parfum",
      longevity: "10-14 hours",
      sillage: "Heavy"
    },
    // Add more detailed products as needed...
  ];

  const product = detailedProducts.find(p => p.id === id);

  useEffect(() => {
    if (!product) {
      navigate('/products');
    }
  }, [product, navigate]);

  if (!product) {
    return null;
  }

  const relatedProducts = detailedProducts
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const discount = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const addToCart = (productToAdd: Product, qty: number = 1) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === productToAdd.id);
      if (existing) {
        return prev.map(item => 
          item.id === productToAdd.id 
            ? { ...item, quantity: item.quantity + qty }
            : item
        );
      }
      return [...prev, { ...productToAdd, quantity: qty }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity === 0) {
      removeItem(productId);
      return;
    }
    setCartItems(prev => 
      prev.map(item => 
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const removeItem = (productId: string) => {
    setCartItems(prev => prev.filter(item => item.id !== productId));
  };

  const toggleFavorite = (productId: string) => {
    setFavorites(prev => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(productId)) {
        newFavorites.delete(productId);
      } else {
        newFavorites.add(productId);
      }
      return newFavorites;
    });
  };

  const totalCartItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const images = product.additionalImages || [product.image];

  return (
    <div className="min-h-screen bg-gradient-elegant">
      <Header 
        cartItems={totalCartItems} 
        onCartClick={() => setIsCartOpen(true)} 
      />
      
      <main className="pt-24">
        {/* Breadcrumb */}
        <section className="py-6 bg-background/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Link to="/" className="hover:text-primary transition-colors">Home</Link>
              <span>/</span>
              <Link to="/products" className="hover:text-primary transition-colors">Products</Link>
              <span>/</span>
              <span className="text-foreground">{product.name}</span>
            </div>
          </div>
        </section>

        {/* Product Detail */}
        <section className="py-12">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <Button 
              variant="ghost" 
              onClick={() => navigate(-1)}
              className="mb-6"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Product Images */}
              <div className="space-y-4">
                <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                  <img 
                    src={images[selectedImage]}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                  />
                </div>
                
                {images.length > 1 && (
                  <div className="flex gap-2 overflow-x-auto">
                    {images.map((img, index) => (
                      <button
                        key={index}
                        onClick={() => setSelectedImage(index)}
                        className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                          selectedImage === index ? 'border-primary' : 'border-transparent'
                        }`}
                      >
                        <img 
                          src={img}
                          alt={`${product.name} ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Product Info */}
              <div className="space-y-6">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="secondary">{product.category}</Badge>
                    {product.isNew && <Badge className="bg-secondary">New</Badge>}
                    {product.isBestseller && <Badge className="bg-primary">Bestseller</Badge>}
                    {discount > 0 && <Badge variant="destructive">-{discount}%</Badge>}
                  </div>
                  
                  <h1 className="text-3xl md:text-4xl font-playfair font-bold text-foreground mb-2">
                    {product.name}
                  </h1>
                  
                  <p className="text-muted-foreground mb-4">{product.brand}</p>
                  
                  <div className="flex items-center gap-4 mb-4">
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-5 w-5 ${i < Math.floor(product.rating) ? 'fill-secondary text-secondary' : 'text-muted-foreground/30'}`} 
                        />
                      ))}
                      <span className="text-sm text-muted-foreground ml-2">
                        {product.rating} ({product.reviews} reviews)
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 mb-6">
                    <span className="text-3xl font-playfair font-bold text-primary">
                      ₦{product.price.toLocaleString()}
                    </span>
                    {product.originalPrice && (
                      <span className="text-xl text-muted-foreground line-through">
                        ₦{product.originalPrice.toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>

                <Separator />

                {/* Quantity and Actions */}
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <span className="font-semibold">Quantity:</span>
                    <div className="flex items-center border rounded-lg">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => quantity > 1 && setQuantity(quantity - 1)}
                        disabled={quantity <= 1}
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      <span className="px-4 py-2 min-w-[3rem] text-center">{quantity}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setQuantity(quantity + 1)}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button 
                      size="lg" 
                      className="flex-1"
                      onClick={() => addToCart(product, quantity)}
                    >
                      <ShoppingCart className="h-5 w-5 mr-2" />
                      Add to Cart - ₦{(product.price * quantity).toLocaleString()}
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="lg"
                      onClick={() => toggleFavorite(product.id)}
                    >
                      <Heart className={`h-5 w-5 ${favorites.has(product.id) ? 'fill-current text-red-500' : ''}`} />
                    </Button>
                    
                    <Button variant="outline" size="lg">
                      <Share2 className="h-5 w-5" />
                    </Button>
                  </div>
                </div>

                <Separator />

                {/* Features */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                    <Shield className="h-6 w-6 text-primary" />
                    <div>
                      <p className="font-semibold text-sm">Authentic</p>
                      <p className="text-xs text-muted-foreground">100% Original</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                    <Truck className="h-6 w-6 text-primary" />
                    <div>
                      <p className="font-semibold text-sm">Free Delivery</p>
                      <p className="text-xs text-muted-foreground">Within Lagos</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                    <RotateCcw className="h-6 w-6 text-primary" />
                    <div>
                      <p className="font-semibold text-sm">7-Day Return</p>
                      <p className="text-xs text-muted-foreground">Easy Returns</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Product Details Tabs */}
            <div className="mt-16">
              <Tabs defaultValue="description" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="description">Description</TabsTrigger>
                  <TabsTrigger value="specifications">Specifications</TabsTrigger>
                  <TabsTrigger value="reviews">Reviews ({product.reviews})</TabsTrigger>
                </TabsList>
                
                <TabsContent value="description" className="mt-6">
                  <div className="prose prose-lg max-w-none">
                    <p className="text-muted-foreground leading-relaxed">
                      {product.description}
                    </p>
                    
                    <h3 className="font-playfair font-semibold text-xl mt-6 mb-4">Key Ingredients</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {product.ingredients.map((ingredient, index) => (
                        <Badge key={index} variant="outline" className="justify-center py-2">
                          {ingredient}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="specifications" className="mt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex justify-between py-2 border-b">
                        <span className="font-semibold">Brand</span>
                        <span>{product.brand}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b">
                        <span className="font-semibold">Volume</span>
                        <span>{product.volume}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b">
                        <span className="font-semibold">Concentration</span>
                        <span>{product.concentration}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="flex justify-between py-2 border-b">
                        <span className="font-semibold">Longevity</span>
                        <span>{product.longevity}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b">
                        <span className="font-semibold">Sillage</span>
                        <span>{product.sillage}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b">
                        <span className="font-semibold">Category</span>
                        <span>{product.category}</span>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="reviews" className="mt-6">
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">Reviews feature coming soon!</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Be the first to review this product
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Related Products */}
            {relatedProducts.length > 0 && (
              <div className="mt-16">
                <h2 className="text-2xl font-playfair font-bold text-foreground mb-8">
                  Related Products
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {relatedProducts.map((relatedProduct) => (
                    <ProductCard
                      key={relatedProduct.id}
                      product={relatedProduct}
                      onAddToCart={addToCart}
                      onToggleFavorite={toggleFavorite}
                      isFavorite={favorites.has(relatedProduct.id)}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>
      </main>

      <Cart
        isOpen={isCartOpen}
        onOpenChange={setIsCartOpen}
        items={cartItems}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeItem}
      />
    </div>
  );
};

export default ProductDetail;