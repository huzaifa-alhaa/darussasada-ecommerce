import { useState } from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import ProductCard, { Product } from "@/components/ProductCard";
import Cart from "@/components/Cart";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Star, MapPin, Phone, Mail, Instagram, Facebook, Twitter } from "lucide-react";

// Import product images
import product1 from "@/assets/product-1.jpg";
import product2 from "@/assets/product-2.jpg";
import product3 from "@/assets/product-3.jpg";
import product4 from "@/assets/product-4.jpg";
interface CartItem extends Product {
  quantity: number;
}
const Index = () => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  // Sample product data
  const products: Product[] = [{
    id: "1",
    name: "Oud Al Malaki Royal",
    price: 25000,
    originalPrice: 30000,
    image: product1,
    category: "Premium Perfumes",
    rating: 4.8,
    reviews: 127,
    isNew: true,
    isBestseller: true
  }, {
    id: "2",
    name: "Golden Elegance Palette",
    price: 15000,
    image: product2,
    category: "Cosmetics",
    rating: 4.6,
    reviews: 89,
    isBestseller: true
  }, {
    id: "3",
    name: "Amber Nights Attar",
    price: 18000,
    originalPrice: 22000,
    image: product3,
    category: "Arabic Perfumes",
    rating: 4.9,
    reviews: 203,
    isNew: true
  }, {
    id: "4",
    name: "Luxury Skincare Set",
    price: 35000,
    image: product4,
    category: "Skincare",
    rating: 4.7,
    reviews: 156
  }];
  const addToCart = (product: Product) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? {
          ...item,
          quantity: item.quantity + 1
        } : item);
      }
      return [...prev, {
        ...product,
        quantity: 1
      }];
    });
    setIsCartOpen(true);
  };
  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity === 0) {
      removeItem(productId);
      return;
    }
    setCartItems(prev => prev.map(item => item.id === productId ? {
      ...item,
      quantity
    } : item));
  };
  const removeItem = (productId: string) => {
    setCartItems(prev => prev.filter(item => item.id !== productId));
  };
  const toggleFavorite = (productId: string) => {
    setFavorites(prev => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(productId)) {
        newFavorites.delete(productId);
      } else {
        newFavorites.add(productId);
      }
      return newFavorites;
    });
  };
  const totalCartItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  return <div className="min-h-screen bg-gradient-elegant">
      <Header cartItems={totalCartItems} onCartClick={() => setIsCartOpen(true)} />
      
      <main>
        <Hero />
        
        {/* Featured Products */}
        <section id="perfumes" className="py-20 bg-background/50">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center space-y-4 mb-16">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-playfair font-bold text-foreground">
                Featured <span className="text-primary">Collection</span>
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Discover our handpicked selection of premium perfumes and luxury cosmetics
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
              {products.map(product => <ProductCard key={product.id} product={product} onAddToCart={addToCart} onToggleFavorite={toggleFavorite} isFavorite={favorites.has(product.id)} />)}
            </div>
            
            <div className="text-center mt-12">
              <Button variant="luxury" size="lg" asChild>
                <Link to="/products">View All Products</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-16 lg:py-20 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto">
                  <Star className="h-8 w-8 text-primary-foreground" />
                </div>
                <h3 className="font-playfair font-semibold text-xl">Premium Quality</h3>
                <p className="text-muted-foreground">Authentic Arabic perfumes and high-end cosmetics</p>
              </div>
              
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-gradient-secondary rounded-full flex items-center justify-center mx-auto">
                  <MapPin className="h-8 w-8 text-secondary-foreground" />
                </div>
                <h3 className="font-playfair font-semibold text-xl">Nationwide Delivery</h3>
                <p className="text-muted-foreground">Fast and secure delivery across Nigeria</p>
              </div>
              
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto">
                  <Phone className="h-8 w-8 text-primary-foreground" />
                </div>
                <h3 className="font-playfair font-semibold text-xl">24/7 Support</h3>
                <p className="text-muted-foreground">Dedicated customer service for your needs</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 lg:py-20 bg-gradient-primary text-primary-foreground">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6 lg:space-y-8">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-playfair font-bold">
              Experience Luxury Like Never Before
            </h2>
            <p className="text-base sm:text-lg opacity-90 max-w-2xl mx-auto">
              Join thousands of satisfied customers who trust DARUS-SA'ADA for their beauty and fragrance needs
            </p>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
              <Button variant="secondary" size="lg" asChild>
                <Link to="/products">Shop Now</Link>
              </Button>
              <Button variant="outline" size="lg" className="border-primary-foreground hover:bg-primary-foreground text-slate-800">
                Learn More
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-foreground text-background py-12 lg:py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
            <div className="space-y-4">
              <h3 className="text-2xl font-playfair font-bold bg-gradient-secondary bg-clip-text text-transparent">
                DARUS-SA'ADA
              </h3>
              <p className="text-sm opacity-80">
                Nigeria's premier destination for authentic Arabic perfumes and luxury cosmetics.
              </p>
              <div className="flex space-x-4">
                <Instagram className="h-5 w-5 opacity-60 hover:opacity-100 cursor-pointer transition-opacity" />
                <Facebook className="h-5 w-5 opacity-60 hover:opacity-100 cursor-pointer transition-opacity" />
                <Twitter className="h-5 w-5 opacity-60 hover:opacity-100 cursor-pointer transition-opacity" />
              </div>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-semibold">Categories</h4>
              <ul className="space-y-2 text-sm opacity-80">
                <li><a href="#" className="hover:opacity-100 transition-opacity">Perfumes</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Cosmetics</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Skincare</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Collections</a></li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-semibold">Support</h4>
              <ul className="space-y-2 text-sm opacity-80">
                <li><a href="#" className="hover:opacity-100 transition-opacity">Contact Us</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Shipping Info</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Returns</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">FAQ</a></li>
              </ul>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-semibold">Contact</h4>
              <div className="space-y-2 text-sm opacity-80">
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  <span>+234 806 6535 188</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <span>info@darus-saada.ng</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <span>Jos, Nigeria</span>
                </div>
              </div>
            </div>
          </div>
          
          <Separator className="my-8 opacity-20" />
          
          <div className="flex flex-col sm:flex-row justify-between items-center text-sm opacity-60">
            <p>© 2025 DARUS-SA'ADA. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 sm:mt-0">
              <a href="#" className="hover:opacity-100 transition-opacity">Privacy Policy</a>
              <a href="#" className="hover:opacity-100 transition-opacity">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>

      <Cart isOpen={isCartOpen} onOpenChange={setIsCartOpen} items={cartItems} onUpdateQuantity={updateQuantity} onRemoveItem={removeItem} />
    </div>;
};
export default Index;