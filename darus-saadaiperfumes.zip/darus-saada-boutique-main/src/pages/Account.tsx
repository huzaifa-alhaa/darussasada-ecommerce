import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  User, 
  Package, 
  MapPin, 
  Heart, 
  Settings, 
  Edit, 
  Plus, 
  Trash2,
  Eye,
  Loader2,
  Home
} from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import type { Tables } from '@/integrations/supabase/types';
import { toast } from 'sonner';

interface Profile {
  id: string;
  user_id: string;
  first_name: string | null;
  last_name: string | null;
  phone: string | null;
  avatar_url: string | null;
}

interface Address {
  id: string;
  type: 'shipping' | 'billing';
  is_default: boolean;
  first_name: string;
  last_name: string;
  company: string | null;
  address_line_1: string;
  address_line_2: string | null;
  city: string;
  state: string;
  postal_code: string;
  country: string;
  phone: string | null;
}

interface Order {
  id: string;
  order_number: string;
  status: string;
  total_amount: number;
  currency: string;
  created_at: string;
  updated_at: string;
  billing_address_id: string | null;
  shipping_address_id: string | null;
  items?: OrderItem[];
}

interface OrderItem {
  id: string;
  order_id: string;
  product_name: string;
  product_image: string | null;
  quantity: number;
  unit_price: number;
  total_price: number;
  created_at: string;
}

interface WishlistItem {
  id: string;
  product_name: string;
  product_image: string | null;
  product_price: number;
  created_at: string;
}

// Map Supabase address rows to the UI Address type with safe narrowing
type DBAddress = Tables<'addresses'>;
const normalizeAddressType = (t: string): Address['type'] => (t === 'shipping' || t === 'billing' ? t : 'shipping');
const mapAddress = (row: DBAddress): Address => ({
  id: row.id,
  type: normalizeAddressType(row.type),
  is_default: !!row.is_default,
  first_name: row.first_name,
  last_name: row.last_name,
  company: row.company,
  address_line_1: row.address_line_1,
  address_line_2: row.address_line_2,
  city: row.city,
  state: row.state,
  postal_code: row.postal_code,
  country: row.country,
  phone: row.phone,
});

const Account = () => {
  const [activeTab, setActiveTab] = useState('profile');
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [wishlist, setWishlist] = useState<WishlistItem[]>([]);
  const [profileForm, setProfileForm] = useState({
    first_name: '',
    last_name: '',
    phone: ''
  });
  const [addressDialogOpen, setAddressDialogOpen] = useState(false);
  const [addressForm, setAddressForm] = useState({
    type: 'shipping' as Address['type'],
    is_default: false,
    first_name: '',
    last_name: '',
    company: '',
    address_line_1: '',
    address_line_2: '',
    city: '',
    state: '',
    postal_code: '',
    country: 'Nigeria',
    phone: ''
  });
  
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  // Load user data
  useEffect(() => {
    if (user) {
      loadUserData();
    }
  }, [user]);

  const loadUserData = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      // Load profile
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (profileError) throw profileError;
      
      if (profileData) {
        setProfile(profileData);
        setProfileForm({
          first_name: profileData.first_name || '',
          last_name: profileData.last_name || '',
          phone: profileData.phone || ''
        });
      }

      // Load addresses
      const { data: addressData, error: addressError } = await supabase
        .from('addresses')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (addressError) throw addressError;
      setAddresses((addressData || []).map(mapAddress));

      // Load orders with their items
      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .select(`
          *,
          order_items (*)
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (orderError) throw orderError;
      
      // Transform the data to match our interface
      const ordersWithItems = (orderData || []).map(order => ({
        ...order,
        items: order.order_items || []
      }));
      
      setOrders(ordersWithItems);

      // Load wishlist
      const { data: wishlistData, error: wishlistError } = await supabase
        .from('wishlist')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (wishlistError) throw wishlistError;
      setWishlist(wishlistData || []);

    } catch (error: any) {
      toast.error('Error loading profile data: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const updateProfile = async () => {
    if (!user) return;
    
    try {
      const { error } = await supabase
        .from('profiles')
        .upsert({
          user_id: user.id,
          first_name: profileForm.first_name,
          last_name: profileForm.last_name,
          phone: profileForm.phone
        });

      if (error) throw error;
      
      toast.success('Profile updated successfully');
      await loadUserData();
    } catch (error: any) {
      toast.error('Error updating profile: ' + error.message);
    }
  };

  const removeFromWishlist = async (itemId: string) => {
    try {
      const { error } = await supabase
        .from('wishlist')
        .delete()
        .eq('id', itemId);

      if (error) throw error;
      
      toast.success('Removed from wishlist');
      await loadUserData();
    } catch (error: any) {
      toast.error('Error removing from wishlist: ' + error.message);
    }
  };

  const addAddress = async () => {
    if (!user) return;
    
    try {
      const { error } = await supabase
        .from('addresses')
        .insert({
          user_id: user.id,
          type: addressForm.type,
          is_default: addressForm.is_default,
          first_name: addressForm.first_name,
          last_name: addressForm.last_name,
          company: addressForm.company || null,
          address_line_1: addressForm.address_line_1,
          address_line_2: addressForm.address_line_2 || null,
          city: addressForm.city,
          state: addressForm.state,
          postal_code: addressForm.postal_code,
          country: addressForm.country,
          phone: addressForm.phone || null
        });

      if (error) throw error;
      
      toast.success('Address added successfully');
      setAddressDialogOpen(false);
      setAddressForm({
        type: 'shipping',
        is_default: false,
        first_name: '',
        last_name: '',
        company: '',
        address_line_1: '',
        address_line_2: '',
        city: '',
        state: '',
        postal_code: '',
        country: 'Nigeria',
        phone: ''
      });
      await loadUserData();
    } catch (error: any) {
      toast.error('Error adding address: ' + error.message);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">My Account</h1>
              <p className="text-muted-foreground mt-2">Manage your account and preferences</p>
            </div>
            <Link to="/">
              <Button variant="outline">
                <Home className="w-4 h-4 mr-2" />
                Back to Store
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="orders" className="flex items-center gap-2">
              <Package className="w-4 h-4" />
              Orders
            </TabsTrigger>
            <TabsTrigger value="addresses" className="flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Addresses
            </TabsTrigger>
            <TabsTrigger value="wishlist" className="flex items-center gap-2">
              <Heart className="w-4 h-4" />
              Wishlist
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
                <CardDescription>Update your personal details and contact information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center space-x-4 mb-6">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={profile?.avatar_url || "/placeholder.svg"} />
                    <AvatarFallback>
                      {profile?.first_name?.charAt(0) || user.email?.charAt(0) || 'U'}
                      {profile?.last_name?.charAt(0) || ''}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="text-xl font-semibold">
                      {profile?.first_name && profile?.last_name 
                        ? `${profile.first_name} ${profile.last_name}`
                        : user.email
                      }
                    </h3>
                    <p className="text-muted-foreground">{user.email}</p>
                    <Badge variant="secondary" className="mt-1">Member</Badge>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input 
                      id="firstName" 
                      value={profileForm.first_name}
                      onChange={(e) => setProfileForm({...profileForm, first_name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input 
                      id="lastName" 
                      value={profileForm.last_name}
                      onChange={(e) => setProfileForm({...profileForm, last_name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" value={user.email || ''} disabled />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input 
                      id="phone" 
                      type="tel" 
                      value={profileForm.phone}
                      onChange={(e) => setProfileForm({...profileForm, phone: e.target.value})}
                    />
                  </div>
                </div>
                <Button className="mt-4" onClick={updateProfile}>Update Profile</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="orders">
            <div className="space-y-4">
              {orders.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-8">
                    <Package className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No orders yet</h3>
                    <p className="text-muted-foreground text-center">
                      When you place your first order, it will appear here.
                    </p>
                    <Link to="/products">
                      <Button className="mt-4">
                        Start Shopping
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ) : (
                orders.map((order) => (
                  <Card key={order.id}>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <div>
                        <CardTitle className="text-base">Order #{order.order_number}</CardTitle>
                        <CardDescription>
                          Placed on {new Date(order.created_at).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </CardDescription>
                      </div>
                      <Badge variant={
                        order.status === 'delivered' ? 'default' : 
                        order.status === 'processing' ? 'secondary' : 
                        order.status === 'shipped' ? 'outline' :
                        order.status === 'confirmed' ? 'secondary' :
                        'destructive'
                      }>
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </Badge>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Order Items */}
                      {order.items && order.items.length > 0 && (
                        <div className="space-y-3">
                          <h4 className="font-medium text-sm">Order Items:</h4>
                          <div className="space-y-2">
                            {order.items.map((item) => (
                              <div key={item.id} className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                                {item.product_image && (
                                  <img 
                                    src={item.product_image} 
                                    alt={item.product_name}
                                    className="w-12 h-12 object-cover rounded-md"
                                  />
                                )}
                                <div className="flex-1 min-w-0">
                                  <p className="font-medium text-sm truncate">{item.product_name}</p>
                                  <p className="text-xs text-muted-foreground">
                                    Qty: {item.quantity} × ₦{item.unit_price.toLocaleString()}
                                  </p>
                                </div>
                                <div className="text-right">
                                  <p className="font-medium text-sm">₦{item.total_price.toLocaleString()}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <Separator />
                      
                      {/* Order Summary */}
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">
                            {order.items?.length || 0} item{(order.items?.length || 0) !== 1 ? 's' : ''}
                          </p>
                          <p className="font-semibold text-lg">
                            Total: ₦{order.total_amount.toLocaleString()}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          {order.status === 'pending' && (
                            <Badge variant="outline" className="text-yellow-600">
                              Payment Pending
                            </Badge>
                          )}
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4 mr-1" />
                            Track Order
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="addresses">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Saved Addresses</h3>
                <Dialog open={addressDialogOpen} onOpenChange={setAddressDialogOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Address
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Add New Address</DialogTitle>
                      <DialogDescription>
                        Add a new shipping or billing address to your account.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 pb-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="addressType">Address Type</Label>
                          <Select value={addressForm.type} onValueChange={(value: Address['type']) => setAddressForm({...addressForm, type: value})}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="shipping">Shipping</SelectItem>
                              <SelectItem value="billing">Billing</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="flex items-center space-x-2 pt-6">
                          <input 
                            type="checkbox" 
                            id="isDefault" 
                            checked={addressForm.is_default}
                            onChange={(e) => setAddressForm({...addressForm, is_default: e.target.checked})}
                            className="rounded border-gray-300"
                          />
                          <Label htmlFor="isDefault">Set as default address</Label>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="addressFirstName">First Name</Label>
                          <Input 
                            id="addressFirstName"
                            value={addressForm.first_name}
                            onChange={(e) => setAddressForm({...addressForm, first_name: e.target.value})}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="addressLastName">Last Name</Label>
                          <Input 
                            id="addressLastName"
                            value={addressForm.last_name}
                            onChange={(e) => setAddressForm({...addressForm, last_name: e.target.value})}
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="company">Company (Optional)</Label>
                        <Input 
                          id="company"
                          value={addressForm.company}
                          onChange={(e) => setAddressForm({...addressForm, company: e.target.value})}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="addressLine1">Address Line 1</Label>
                        <Input 
                          id="addressLine1"
                          value={addressForm.address_line_1}
                          onChange={(e) => setAddressForm({...addressForm, address_line_1: e.target.value})}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="addressLine2">Address Line 2 (Optional)</Label>
                        <Input 
                          id="addressLine2"
                          value={addressForm.address_line_2}
                          onChange={(e) => setAddressForm({...addressForm, address_line_2: e.target.value})}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="city">City</Label>
                          <Input 
                            id="city"
                            value={addressForm.city}
                            onChange={(e) => setAddressForm({...addressForm, city: e.target.value})}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="state">State</Label>
                          <Input 
                            id="state"
                            value={addressForm.state}
                            onChange={(e) => setAddressForm({...addressForm, state: e.target.value})}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="postalCode">Postal Code</Label>
                          <Input 
                            id="postalCode"
                            value={addressForm.postal_code}
                            onChange={(e) => setAddressForm({...addressForm, postal_code: e.target.value})}
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="country">Country</Label>
                          <Input 
                            id="country"
                            value={addressForm.country}
                            onChange={(e) => setAddressForm({...addressForm, country: e.target.value})}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="addressPhone">Phone (Optional)</Label>
                          <Input 
                            id="addressPhone"
                            type="tel"
                            value={addressForm.phone}
                            onChange={(e) => setAddressForm({...addressForm, phone: e.target.value})}
                          />
                        </div>
                      </div>

                      <div className="flex justify-end space-x-2 pt-4">
                        <Button variant="outline" onClick={() => setAddressDialogOpen(false)}>
                          Cancel
                        </Button>
                        <Button onClick={addAddress}>
                          Add Address
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
              
              {addresses.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-8">
                    <MapPin className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No addresses saved</h3>
                    <p className="text-muted-foreground text-center">
                      Add your shipping and billing addresses for faster checkout.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                addresses.map((address) => (
                  <Card key={address.id}>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-4 h-4" />
                        <CardTitle className="text-base">
                          {address.type.charAt(0).toUpperCase() + address.type.slice(1)} Address
                        </CardTitle>
                        {address.is_default && <Badge variant="secondary">Default</Badge>}
                      </div>
                      <div className="space-x-2">
                        <Button variant="ghost" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-1">
                        <p className="font-medium">{address.first_name} {address.last_name}</p>
                        {address.company && <p className="text-sm">{address.company}</p>}
                        <p className="text-sm text-muted-foreground">{address.address_line_1}</p>
                        {address.address_line_2 && (
                          <p className="text-sm text-muted-foreground">{address.address_line_2}</p>
                        )}
                        <p className="text-sm text-muted-foreground">
                          {address.city}, {address.state} {address.postal_code}
                        </p>
                        <p className="text-sm text-muted-foreground">{address.country}</p>
                        {address.phone && <p className="text-sm text-muted-foreground">{address.phone}</p>}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="wishlist">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">My Wishlist</h3>
              
              {wishlist.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-8">
                    <Heart className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Your wishlist is empty</h3>
                    <p className="text-muted-foreground text-center">
                      Start adding items to your wishlist by clicking the heart icon on products.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {wishlist.map((item) => (
                    <Card key={item.id}>
                      <CardContent className="p-4">
                        <div className="aspect-square mb-4 overflow-hidden rounded-lg">
                          <img 
                            src={item.product_image || '/placeholder.svg'} 
                            alt={item.product_name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <h4 className="font-semibold mb-2">{item.product_name}</h4>
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-lg font-bold">₦{item.product_price.toLocaleString()}</span>
                        </div>
                        <div className="flex gap-2">
                          <Button className="flex-1">Add to Cart</Button>
                          <Button 
                            variant="outline" 
                            size="icon"
                            onClick={() => removeFromWishlist(item.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Account;