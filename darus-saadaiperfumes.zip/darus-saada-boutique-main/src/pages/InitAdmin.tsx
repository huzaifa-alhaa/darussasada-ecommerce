import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { Link } from 'react-router-dom';

const InitAdmin = () => {
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<'pending' | 'success' | 'error'>('pending');

  const createAdminUser = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('create-admin-user');
      
      if (error) {
        console.error('Error creating admin user:', error);
        toast.error('Failed to create admin user');
        setStatus('error');
        return;
      }
      
      toast.success('Admin user created successfully!');
      setStatus('success');
    } catch (error) {
      console.error('Error:', error);
      toast.error('Failed to create admin user');
      setStatus('error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Shield className="h-12 w-12 text-primary" />
          </div>
          <CardTitle className="text-2xl">Initialize Admin</CardTitle>
          <p className="text-muted-foreground">
            Set up the admin account for DARUS-SA'ADA
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="bg-muted p-4 rounded-lg space-y-2">
              <h3 className="font-semibold">Admin Credentials</h3>
              <p className="text-sm text-muted-foreground">
                <strong>Email:</strong> admin@darussaada.com.ng
              </p>
              <p className="text-sm text-muted-foreground">
                <strong>Password:</strong> password123
              </p>
            </div>
            
            {status === 'pending' && (
              <Button 
                onClick={createAdminUser} 
                disabled={loading}
                className="w-full"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating Admin User...
                  </>
                ) : (
                  <>
                    <Shield className="mr-2 h-4 w-4" />
                    Create Admin User
                  </>
                )}
              </Button>
            )}
            
            {status === 'success' && (
              <div className="text-center space-y-4">
                <div className="flex items-center justify-center text-green-600">
                  <CheckCircle className="h-8 w-8" />
                </div>
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  Admin user created successfully
                </Badge>
                <div className="space-y-2">
                  <Link to="/auth">
                    <Button className="w-full">
                      Go to Login
                    </Button>
                  </Link>
                  <Link to="/">
                    <Button variant="outline" className="w-full">
                      Back to Store
                    </Button>
                  </Link>
                </div>
              </div>
            )}
            
            {status === 'error' && (
              <div className="text-center space-y-4">
                <div className="flex items-center justify-center text-red-600">
                  <XCircle className="h-8 w-8" />
                </div>
                <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                  Failed to create admin user
                </Badge>
                <Button 
                  onClick={createAdminUser} 
                  disabled={loading}
                  variant="outline"
                  className="w-full"
                >
                  Try Again
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default InitAdmin;