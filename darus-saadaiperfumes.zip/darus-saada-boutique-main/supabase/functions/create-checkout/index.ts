import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[CREATE-CHECKOUT] ${step}${detailsStr}`);
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Checkout function started");

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? ""
    );

    // Parse request body to get cart items
    const { items } = await req.json();
    if (!items || !Array.isArray(items) || items.length === 0) {
      throw new Error("No items provided for checkout");
    }
    logStep("Cart items received", { itemCount: items.length });

    // Get authenticated user (optional for guest checkout)
    let user = null;
    let customerId = null;
    let customerEmail = null;

    const authHeader = req.headers.get("Authorization");
    if (authHeader) {
      const token = authHeader.replace("Bearer ", "");
      const { data } = await supabaseClient.auth.getUser(token);
      user = data.user;
      logStep("User authenticated", { userId: user?.id, email: user?.email });
    }

    // Initialize Stripe
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2025-08-27.basil",
    });
    logStep("Stripe initialized");

    // Check if customer exists for authenticated users
    if (user?.email) {
      const customers = await stripe.customers.list({ 
        email: user.email, 
        limit: 1 
      });
      if (customers.data.length > 0) {
        customerId = customers.data[0].id;
        logStep("Existing customer found", { customerId });
      } else {
        // For new customers, we'll let Stripe create the customer during checkout
        customerEmail = user.email;
        logStep("New customer, will use email", { customerEmail });
      }
    }

    // For now, we'll use the existing Golden Elegance product for all items
    // In a real store, you'd map each cart item to its corresponding Stripe price
    const lineItems = items.map((item: any) => ({
      price: "price_1S86VAGexDWnNZMK16HxBxJD", // Golden Elegance price
      quantity: item.quantity || 1,
    }));

    logStep("Line items prepared", { lineItems });

    // Create checkout session
    const checkoutParams: any = {
      line_items: lineItems,
      mode: "payment",
      success_url: `${req.headers.get("origin")}/checkout-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${req.headers.get("origin")}/checkout-cancelled`,
      billing_address_collection: "required",
      shipping_address_collection: {
        allowed_countries: ["NG"], // Nigeria for now, can be expanded
      },
      payment_method_types: ["card"],
    };

    // Only add customer OR customer_email, never both
    if (customerId) {
      checkoutParams.customer = customerId;
      logStep("Using existing customer ID", { customerId });
    } else if (customerEmail) {
      checkoutParams.customer_email = customerEmail;
      logStep("Using customer email for new customer", { customerEmail });
    }

    const session = await stripe.checkout.sessions.create(checkoutParams);

    logStep("Checkout session created", { sessionId: session.id, url: session.url });

    return new Response(JSON.stringify({ url: session.url, sessionId: session.id }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR in create-checkout", { message: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});